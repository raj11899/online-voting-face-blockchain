import requests
pno = "9515851969"

url = "https://www.fast2sms.com/dev/bulkV2"

message = 'Hi ' + "lakshmi" + ' You voted successfully. Thank you for voting at. '
no = pno
# message = "helloo hai"
data1 = {
    "route": "q",
    "message": message,
    "language": "english",
    "flash": 0,
    "numbers": no,
}

headers = {
    "authorization": "WcXR9tri6LwK7qCyG54NdbHslhmfP12xu08vSJZEzIgDUMQjOkx7AbzLaDeJhOWwoUd29ZgpjEcRXQ1H",
    "Content-Type": "application/json"
}

response = requests.post(url, headers=headers, json=data1)
print(response)