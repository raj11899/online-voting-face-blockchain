from flask import Flask, render_template, url_for, request, session, flash, redirect
# from flask_mail import *
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import smtplib
import pymysql
import pandas as pd
import numpy as np
import os
import cv2
import random
from PIL import Image
import shutil
import datetime
import time
import requests
from web3 import Web3
import json
web3=Web3(Web3.HTTPProvider('http://127.0.0.1:7545'))
one={
    'from':"0xc7Da9efc3C66762d001ba37379A9D9894DEa30aB"
}
with open('blocks/build/contracts/User.json')as j:
    contract_user = web3.eth.contract(
        address="0x6A4AB57a90B5BD6634aEB52559E9D1081fBf90D9",abi=json.load(j)['abi']
    )


facedata = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"
cascade = cv2.CascadeClassifier(facedata)

mydb=pymysql.connect(host='localhost', user='root', password='root', port=3306, database='smart_voting_system')
sender_address ="psreekanth472@gmail.com" #enter sender's email id
sender_pass = 'qiokbxmlczeqvfna'




app=Flask(__name__)
app.config['SECRET_KEY']='ajsihh98rw3fyes8o3e9ey3w5dc'

@app.before_first_request
def initialize():
    session['IsAdmin']=False
    session['User']=None

@app.route('/')
@app.route('/home')
def home():
    return render_template('index.html')

@app.route('/admin', methods=['POST','GET'])
def admin():
    # session['IsAdmin']=False
    if request.method=='POST':
        email = request.form['email']
        password = request.form['password']
        if (email=='admin@voting.com') and (password=='admin'):
            session['IsAdmin']=True
            session['User']='admin'
            flash('Admin login successful','success')
        else:
            print("jkjfdjh")
            return render_template('adminlogin.html') 
    return render_template('adminlogin.html', admin=session['IsAdmin'])

@app.route('/custome', methods=['POST', 'GET'])
def custome():
    if request.method == 'POST':
        # Get the uploaded file and form data
        party_symbol = request.files['party_symbol']
        party_name = request.form['party_name']
        nominee_name = request.form['member_name']
        print(party_name, party_symbol, nominee_name)
        print(party_symbol.filename)

        # Check the uploaded image format and accept it only if it's PNG, JPG, JFIF, or JPEG
        if party_symbol.filename.split('.')[-1] not in ['png', 'jpg', 'jfif', 'jpeg']:
            flash(r"Please upload a valid image file", 'info')
            return redirect(url_for('custome'))

        # Fetch existing nominee data
        nominee = pd.read_sql_query('SELECT * FROM nominee', mydb)
        all_members = nominee.member_name.values
        all_parties = nominee.party_name.values
        all_symbols = nominee.symbol_name.values

        if party_name in all_parties:
            flash(r'The party already exists', 'info')
        elif party_symbol.filename in all_symbols:
            flash(r"The symbol is already taken", 'info')
        elif nominee_name in all_members:
            flash(r"The member is already registered", 'info')
        else:
            # Directly save the symbol in the 'static/logos' folder
            logo_folder_path = os.path.join(os.getcwd(), "static/logos")

            # Ensure that the file doesn't already exist to avoid overwriting (optional)
            file_path = os.path.join(logo_folder_path, party_symbol.filename)
            if os.path.exists(file_path):
                flash(r"An image with this name already exists. Please rename the image and try again.", 'info')
                return redirect(url_for('custome'))

            # Save the image in the logos folder
            party_symbol.save(file_path)

            # Save the party name, symbol name, and nominee name into the database
            sql = 'INSERT INTO nominee (party_name, symbol_name, member_name) VALUES (%s, %s, %s)'
            cur = mydb.cursor()
            cur.execute(sql, (party_name, party_symbol.filename, nominee_name))
            mydb.commit()
            cur.close()

            flash(r"Successfully registered a new nominee", 'primary')

    return render_template('custome.html')



@app.route('/add_nominee', methods=['POST','GET'])
def add_nominee():
    if request.method=='POST':
        member=request.form['member_name']
        party=request.form['party_name']
        logo=request.form['test']
        nominee=pd.read_sql_query('SELECT * FROM nominee', mydb)
        all_members=nominee.member_name.values
        all_parties=nominee.party_name.values
        all_symbols=nominee.symbol_name.values
        if member in all_members:
            flash(r'The member already exists', 'info')
        elif party in all_parties:
            flash(r"The party already exists", 'info')
        elif logo in all_symbols:
            flash(r"The logo is already taken", 'info')
        else:
            sql="INSERT INTO nominee (member_name, party_name, symbol_name) VALUES (%s, %s, %s)"
            cur=mydb.cursor()
            cur.execute(sql, (member, party, logo))
            mydb.commit()
            cur.close()
            flash(r"Successfully registered a new nominee", 'primary')
    return render_template('nominee.html', admin=session['IsAdmin'])

@app.route('/registration', methods=['POST','GET'])
def registration():
    if request.method=='POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        middle_name = request.form['middle_name']
        aadhar_id = request.form['aadhar_id']
        voter_id = request.form['voter_id']
        pno = request.form['pno']
        age = int(request.form['age'])
        email = request.form['email']
        voters=contract_user.functions.getusers().call(one)
        all_aadhar_ids=[]
        all_voter_ids=[]
        if voters:
            all_aadhar_ids=voters[4]
            all_voter_ids=voters[5]
        if age >= 18:
            if (aadhar_id in all_aadhar_ids) or (voter_id in all_voter_ids):
                flash(r'Already Registered as a Voter')
            else:
                contract_user.functions.addUser(
                    1,first_name,middle_name,last_name,aadhar_id,voter_id,email,pno,'no','','',''
                ).transact(one)
                session['aadhar']=aadhar_id
                session['status']='no'
                session['email']=email
                return redirect(url_for('verify'))
        else:
            flash("if age less than 18 then not eligible for voting","info")
    return render_template('voter_reg.html')

@app.route('/verify', methods=['POST','GET'])
def verify():
    if session['status']=='no':
        if request.method=='POST':
            # print(session['otp'])
            otp_check=request.form['otp_check']
            if otp_check==session['otp']:
                session['status']='yes'
                contract_user.functions.updateVerifiedByAadhar(str(session['aadhar']),str(session['status'])).transact(one)
                flash(r"Email verified successfully",'primary')
                return redirect(url_for('capture_images')) #change it to capture photos
            else:
                flash(r"Wrong OTP. Please try again.","info")
                return redirect(url_for('verify'))
        else:
            #Sending OTP
            message = MIMEMultipart()
            receiver_address = session['email']
            message['From'] = sender_address
            message['To'] = receiver_address
            Otp = str(np.random.randint(100000, 999999))
            print(Otp)
            session['otp']=Otp
            message.attach(MIMEText(session['otp'], 'plain'))
            abc = smtplib.SMTP('smtp.gmail.com', 587)
            abc.starttls()
            abc.login(sender_address, sender_pass)
            text = message.as_string()
            abc.sendmail(sender_address, receiver_address, text)
            abc.quit()
            print(session['otp'])
    else:
        flash(r"Your email is already verified", 'warning')
    return render_template('verify.html')

@app.route('/capture_images', methods=['POST','GET'])
def capture_images():
    if request.method=='POST':
        cam=cv2.VideoCapture(0, cv2.CAP_DSHOW)
        sampleNum = 0
        path_to_store=os.path.join(os.getcwd(),"all_images\\"+session['aadhar'])
        try:
            shutil.rmtree(path_to_store)
        except:
            pass
        os.makedirs(path_to_store, exist_ok=True)
        while (True):
            ret, img = cam.read()
            try:
                gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            except:
                continue
            faces = cascade.detectMultiScale(gray, 1.3, 5)
            for (x, y, w, h) in faces:
                cv2.rectangle(img, (x, y), (x + w, y + h), (255, 0, 0), 2)
                # incrementing sample number
                sampleNum = sampleNum + 1
                # saving the captured face in the dataset folder TrainingImage
                cv2.imwrite(path_to_store +r'\\'+ str(sampleNum) + ".jpg", gray[y:y + h, x:x + w])
                # display the frame
            else:
                cv2.imshow('frame', img)
                cv2.setWindowProperty('frame', cv2.WND_PROP_TOPMOST, 1)
            # wait for 100 miliseconds
            if cv2.waitKey(100) & 0xFF == ord('q'):
                break
            # break if the sample number is morethan 100
            elif sampleNum >= 100:
                break
        cam.release()
        cv2.destroyAllWindows()
        flash("Registration successfully completed","success")
        return redirect(url_for('home'))
    return render_template('capture.html')

from sklearn.preprocessing import LabelEncoder
import pickle
le = LabelEncoder()

def getImagesAndLabels(path):
    folderPaths = [os.path.join(path, f) for f in os.listdir(path)]
    faces = []
    Ids = []
    global le
    for folder in folderPaths:
        imagePaths = [os.path.join(folder, f) for f in os.listdir(folder)]
        aadhar_id = folder.split("\\")[1]
        for imagePath in imagePaths:
            # loading the image and converting it to gray scale
            pilImage = Image.open(imagePath).convert('L')
            # Now we are converting the PIL image into numpy array
            imageNp = np.array(pilImage, 'uint8')
            # extract the face from the training image sample
            faces.append(imageNp)
            Ids.append(aadhar_id)
            # Ids.append(int(aadhar_id))
    Ids_new=le.fit_transform(Ids).tolist()
    output = open('encoder.pkl', 'wb')
    pickle.dump(le, output)
    output.close()
    return faces, Ids_new

@app.route('/train', methods=['POST','GET'])
def train():
    if request.method=='POST':
        recognizer = cv2.face.LBPHFaceRecognizer_create()
        faces, Id = getImagesAndLabels(r"all_images")
        print(Id)
        print(len(Id))
        recognizer.train(faces, np.array(Id))
        recognizer.save("Trained.yml")
        flash(r"Model Trained Successfully", 'Primary')
        return redirect(url_for('home'))
    return render_template('train.html')
@app.route('/update')
def update():
    return render_template('update.html')
@app.route('/updateback', methods=['POST','GET'])
def updateback():
    if request.method=='POST':
        first_name = request.form['first_name']
        last_name = request.form['last_name']
        voter_id = request.form['voter_id']
        email = request.form['email']
        pno = request.form['pno']
        age = int(request.form['age'])
        voters=contract_user.functions.getusers().call(one)
        if voters:
            all_aadhar_ids=voters[5]
        if all_aadhar_ids:
            if age >= 18:

                contract_user.functions.updateByVoterId(str(voter_id),str(first_name),str(last_name),str(voter_id),str(email),str(pno)).transact(one)
                flash(r' Updated Successfully in Block chain','Primary')
                return redirect(url_for('home'))           
            else:
                flash("age should be 18 or greater than 18 is eligible", "info")
        else:
            flash("Aadhar didn't match, try again","primary")
    return render_template('update.html')

@app.route('/voting', methods=['POST','GET'])
def voting():
    pkl_file = open('encoder.pkl', 'rb')
    my_le = pickle.load(pkl_file)
    pkl_file.close()
    recognizer = cv2.face.LBPHFaceRecognizer_create()  # cv2.createLBPHFaceRecognizer()
    recognizer.read("Trained.yml")
    cam=cv2.VideoCapture(0, cv2.CAP_DSHOW)
    font = cv2.FONT_HERSHEY_SIMPLEX
    flag = 0
    detected_persons=[]
    global det
    det=0
    while True:
        ret, im = cam.read()
        flag += 1
        if flag==200:
            flash(r"Unable to detect person. Contact help desk for manual voting", "info")
            cv2.destroyAllWindows()
            return render_template('voting.html')
        gray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
        faces = cascade.detectMultiScale(gray, 1.2, 5)
        print(faces)
        for (x, y, w, h) in faces:
            cv2.rectangle(im, (x, y), (x + w, y + h), (225, 0, 0), 2)
            Id, conf = recognizer.predict(gray[y:y + h, x:x + w])
            print(conf)
            if (conf > 40):
                det +=1
                det_aadhar = my_le.inverse_transform([Id])[0]
                detected_persons.append(det_aadhar)
                if det >=20:
                    session['select_aadhar']=det_aadhar
                    return redirect(url_for('select_candidate'))

                cv2.putText(im, f"Aadhar: {det_aadhar}", (x, y + h), font, 1, (255, 255, 255), 2)
            else:
                cv2.putText(im, "Unknown", (x, y + h), font, 1, (255, 255, 255), 2)
        cv2.imshow('im', im)
        try:
            cv2.setWindowProperty('im', cv2.WND_PROP_TOPMOST, 1)
        except:
            pass
        if (cv2.waitKey(1) == (ord('q')) ):
            try:
                session['select_aadhar']=det_aadhar
            except:
                cv2.destroyAllWindows()
                return redirect(url_for('home'))
            cv2.destroyAllWindows()
            return redirect(url_for('select_candidate'))


@app.route('/select_candidate1', methods=['POST','GET'])
def select_candidate1():

    df_nom = pd.read_sql_query('select * from nominee', mydb)
    # all_nom = df_nom['symbol_name'].values
    # all_party = df_nom['party_name'].values
    # all_member = df_nom['member_name'].values
    # i need an array of all the above values in signle array
   #i need 
    print(df_nom.values)

    sq = "select * from vote"
    g = pd.read_sql_query(sq, mydb)
    
   
    if request.method == 'POST':
        vote = request.form['test']
        session['vote'] = vote
        sql = "INSERT INTO vote (vote, aadhar) VALUES ('%s', '%s')" % (vote, aadhar)
        cur = mydb.cursor()
        cur.execute(sql)
        mydb.commit()
        cur.close()
        s = "select * from voters where aadhar_id='" + aadhar + "'"
        c = pd.read_sql_query(s, mydb)
        pno = str(c.values[0][7])
        name = str(c.values[0][1])
        ts = time.time()
        date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
        timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
        url = "https://www.fast2sms.com/dev/bulkV2"

        message = 'Hi ' + name + ' You voted successfully. Thank you for voting at ' + timeStamp + ' on ' + date + '.'
        no = pno
        # message = "helloo hai"
        data1 = {
            "route": "q",
            "message": message,
            "language": "english",
            "flash": 0,
            "numbers": no,
        }

        headers = {
            "authorization": "UwmaiQR5OoA6lSTz93nP0tDxsFEhI7VJrfKkvYjbM2C14Wde8g9lvA2Ghq5VNCjrZ4THWkF1KOwp3Bxd",
            "Content-Type": "application/json"
        }

        response = requests.post(url, headers=headers, json=data1)
        print(response)

        flash(r"Voted Successfully", 'Primary')
        return redirect(url_for('home'))
    return render_template('select_candidate.html', noms=df_nom.values)
    

@app.route('/select_candidate', methods=['POST','GET'])
def select_candidate():
    aadhar = session['select_aadhar']

    df_nom = pd.read_sql_query('select * from nominee', mydb)
    # all_nom = df_nom['symbol_name'].values
    sq = "select * from vote"
    g = pd.read_sql_query(sq, mydb)
    all_adhar = g['aadhar'].values
    if aadhar in all_adhar:
        flash("You already voted", "warning")
        return redirect(url_for('home'))
    else:
        if request.method == 'POST':
            vote = request.form['test']
            session['vote'] = vote
            sql = "INSERT INTO vote (vote, aadhar) VALUES ('%s', '%s')" % (vote, aadhar)
            cur = mydb.cursor()
            cur.execute(sql)
            mydb.commit()
            cur.close()
            c = contract_user.functions.getusers().call(one)
            pno = ""
            name = ""
            for i in range(len(c[0])):
                if i[4][i]==aadhar:
                    pno=i[7][i]
                    name=i[3][i]    
            ts = time.time()
            date = datetime.datetime.fromtimestamp(ts).strftime('%Y-%m-%d')
            timeStamp = datetime.datetime.fromtimestamp(ts).strftime('%H:%M:%S')
            url = "https://www.fast2sms.com/dev/bulkV2"

            message = 'Hi ' + name + ' You voted successfully. Thank you for voting at ' + timeStamp + ' on ' + date + '.'
            no = pno
            # message = "helloo hai"
            data1 = {
                "route": "q",
                "message": message,
                "language": "english",
                "flash": 0,
                "numbers": no,
            }

            headers = {
                "authorization": "UwmaiQR5OoA6lSTz93nP0tDxsFEhI7VJrfKkvYjbM2C14Wde8g9lvA2Ghq5VNCjrZ4THWkF1KOwp3Bxd",
                "Content-Type": "application/json"
            }

            response = requests.post(url, headers=headers, json=data1)
            print(response)

            flash(r"Voted Successfully", 'Primary')
            return redirect(url_for('home'))
    return render_template('select_candidate.html', noms=df_nom.values)
    

@app.route('/voting_res')
def voting_res():
    df_nom = pd.read_sql_query('''select
            n.party_name,
            n.symbol_name,
            count(v.vote) as vote_count
            from nominee n
            left join vote v on v.vote = n.symbol_name
            group by v.vote order by vote_count desc''', mydb
        )
    
    return render_template('voting_res.html', noms=df_nom.values)

if __name__=='__main__':
    app.run(debug=True)

