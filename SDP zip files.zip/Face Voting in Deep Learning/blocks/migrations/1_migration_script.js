const exp = artifacts.require('User')
module.exports = (d)=>{
d.deploy(exp)
}